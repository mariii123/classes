package model;

public class Aluno {
        private String nome;
        private String enderecp;
        private String gmail;
        private String telefone;
        private String senha;
        
        public String getAltnome() {
            return nome;
        }

        public void setAltnome(String altnome) {
            this.nome = altnome;
        }

        public String getAltenderecp() {
            return enderecp;
        }

        public void setAltenderecp(String altenderecp) {
            this.enderecp = altenderecp;
        }

        public String getAltgmail() {
            return gmail;
        }

        public void setAltgmail(String altgmail) {
            this.gmail = altgmail;
        }

        public String getAlttelefone() {
            return telefone;
        }

        public void setAlttelefone(String alttelefone) {
            this.telefone = alttelefone;
        }

        public String getAltsenha() {
            return senha;
        }

        public void setAltsenha(String altsenha) {
            this.senha = altsenha;
        }

        @Override
        public String toString() {
            return "mudarperfil{" +
                    "altnome='" + nome + '\'' +
                    ", altenderecp='" + enderecp + '\'' +
                    ", altgmail='" + gmail + '\'' +
                    ", alttelefone='" + telefone + '\'' +
                    ", altsenha='" + senha + '\'' +
                    '}';
        }
    }

