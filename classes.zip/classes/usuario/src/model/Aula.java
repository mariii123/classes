package model;

public class Aula {
    private String url;
    private int id;
    private String descricao;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "Aula{" +
                "url='" + url + '\'' +
                ", id=" + id +
                ", descricao='" + descricao + '\'' +
                '}';
    }
}
